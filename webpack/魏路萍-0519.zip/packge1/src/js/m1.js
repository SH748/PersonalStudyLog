//分别暴露
export let name = "盲僧";
export let position = "打野";

