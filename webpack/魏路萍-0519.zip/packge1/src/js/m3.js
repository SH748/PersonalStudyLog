//默认暴露
export default {
    game: "王者荣耀",
    company: "Tencent"
}