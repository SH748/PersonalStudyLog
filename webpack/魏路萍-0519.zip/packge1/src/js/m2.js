let sheshou = {
    name: "后裔",
    position: "下路"
};

let fuzhu = {
    name: "蔡文姬",
    position: "辅助"
}

//统一暴露
export {sheshou, fuzhu};